# Overview

TechChallengeApp is deployed into Azure Kubernetes Service(AKS) using the following,

1. Terraform - for provisioning Azure resources
2. Helm - for kubernetes deployment

## Prerequisite

Following env/tools are used,
1. Ubuntu     - 18.04.5 LTS
2. kubectl    - 1.17
3. az         - 2.10.1
4. docker     - 19.03
5. terraform  - 0.11.14
6. kubernetes - 1.17.9 

## Build

Build container image and push to image registry (dockerhub), using the following commands,

        git clone https://github.com/servian/TechChallengeApp.git
        cd TechChallengeApp
        go get -d github.com/servian/TechChallengeApp
        docker build . -t techchallengeapp:latest
        docker images
        docker tag <image_id_from_above> snehid/testservian:latest
        docker push snehid/testservian:latest
 
## Infrastructure provisioning

I used terraform to provision following resources in Azure,
1. Azure Postgres
2. Azure Kubernetes Service (AKS)

Steps are listed below, two pods (high available)

        cd ../infra
        ## populate appropriate Azure login parameters in below script
        source ./init_script/init_script.sh
        terraform plan
        terraform apply

## Deployment

Now, get kubeconfig values to local,

        az login
        az account set --subscription ${ARM_SUBSCRIPTION_ID}
        az account show
        az aks get-credentials --overwrite-existing --resource-group aks-cdtest --name  cdtest-aks
        kubectl config use-context cdtest-aks
        kubectl config current-context

### Deploy nginx ingress controller
Frontend nginx will have two replicas to provide high available solution pointing to two pods on k8s
Create namespace

        kubectl create namespace ingress-basic

Add the ingress-nginx repository

        helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx

Use Helm to deploy an NGINX ingress controller

        helm install nginx-ingress ingress-nginx/ingress-nginx \
            --namespace ingress-basic \
            --set controller.replicaCount=2 \
            --set controller.nodeSelector."beta\.kubernetes\.io/os"=linux \
            --set defaultBackend.nodeSelector."beta\.kubernetes\.io/os"=linux 

### Deploy TechChallengeApp

Use helm to deploy TechChallengeApp. Override default values in `values.yaml` using `--set`if required
Update helm `values.yaml` with the required db parameters.
        cd ../helm
        helm upgrade --create-namespace --namespace ingress-basic --install servapp stable/servapp  

### Populate Database (one off)

 
Create table and populate seed data,

        kubectl get pods --namespace ingress-basic   # record pod name
        kubectl exec -it --namespace=ingress-basic <pod-name-from-above-output> -- ash -c "./TechChallengeApp updatedb -s"

### Access Application

Use following command to get public ip and hit it on brower (http://{public-ip}),

        kubectl --namespace ingress-basic get services -o wide -w nginx-ingress-ingress-nginx-controller

## Cleanup resources

        kubectl delete namespace ingress-basic
        cd ../infra
        terraform destroy

## Improvements

1. To setup pipelines for infra provisioning & deployment
2. To retrive all secrets from vault server 
3. To use cert-manager to create and maintain TLS certificate

## Author
Santhosh Ganesan (snehid@gmail.com)