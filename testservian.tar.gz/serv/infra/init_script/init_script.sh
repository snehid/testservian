#!/bin/bash

## Azure params
export ARM_TENANT_ID=""
export ARM_CLIENT_ID=""
export ARM_CLIENT_SECRET=""
export ARM_SUBSCRIPTION_ID=""

## AKS params
export TF_VAR_aks_application_id=$ARM_CLIENT_ID
export TF_VAR_aks_application_secret=$ARM_CLIENT_SECRET
export TF_VAR_aks_ssh_public_key="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDbojwGK5NAWmgLFNRGYcmZXPPf1V8uiZBWev0KwvTh9KhUgN+5ANkw+580i47m1lQa8KteJBYLEehVcfsV39ZR0KY2zPZBsOvJ0qh7m0NZkgzqGnORV/zbUWpF4jTHsItyetrqpt/GS1+DbnyJM9yzDQyBTAeysbUpabX8PBbRFE3JytFNaDP4VAvaXPxE/+wvkMQMwZTDtLOjilgzOatOWnaX2G4LY224eIRN/K+9q/6v4JrIjRgyG07lsP/ukvVamMkpQDlVBdzuIwZTfc2bTbQ06BUCXuoXrROTerbCGkI5gOcebKKC1QaI+/nnKCRd3JDW6yt348ucfQrH7ti/ devops@ubuntu"

## Postgres DB params
export TF_VAR_db_username="servapp"
export TF_VAR_db_password="g5FCT69YjDZjcGPF4eR2e"

terraform init
